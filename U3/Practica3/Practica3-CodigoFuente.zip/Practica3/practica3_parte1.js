// PARTE 1 - Practica 3
// CONECTANDO CON MONGODB

// el 'require' es necesario para cargar el modulo de mongoDB
const mongoose = require('mongoose');

// esta linea conecta con nuestro cluster en la web
mongoose.connect('mongodb+srv://yveelilop:ClusterPSP@clusterpsp.wy5yj.mongodb.net/');

// podemos comprobar el estado de conexion con las siguientes lineas
mongoose.connect('mongodb+srv://yveelilop:ClusterPSP@clusterpsp.wy5yj.mongodb.net/')
    .then(() => {
        console.log('Conexión exitosa a MongoDB');
    }).catch(err => {
        console.error('Error al conectar a MongoDB:', err);
    });

// con esta linea estamos conectando al cluster y a una base de datos de nuestra eleccion
var databasePath = 'databaseTest1';
mongoose.connect(`mongodb+srv://yveelilop:ClusterPSP@clusterpsp.wy5yj.mongodb.net/${databasePath}`);
