// PARTE 2 - Practica 3
// CREACION DE DOCUMENTOS

const mongoose = require('mongoose');
var databasePath = 'databaseTest1';
mongoose.connect(`mongodb+srv://yveelilop:ClusterPSP@clusterpsp.wy5yj.mongodb.net/${databasePath}`);

// Creamos el esquema para añadir una coleccion de documentos
let deportesSchema = new mongoose.Schema({
    deporte: String,
    nombre_equipo: String
});

// Creamos el documento
let Deporte = mongoose.model('collectionTest1', deportesSchema, 'collectionTest1');

// Creamos el dato que contiene el documento
let deporte1 = new Deporte({
    deporte: "Baloncesto",
    nombre_equipo: "Lucentum HLA"
});

// Guardamos el dato DENTRO de la coleccion
deporte1.save().then(
    result => {
        console.log("Deporte añadido:", result);
    }
).catch(
    error => {
        console.log("Error añadiendo deporte", error);
    }
);
