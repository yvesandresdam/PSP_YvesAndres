// PARTE 4 - Practica 3
// BUSQUEDA DE DOCUMENTOS

const mongoose = require('mongoose');

// Linea que conecta con el cluster y la base de datos
mongoose.connect('mongodb+srv://yveelilop:ClusterPSP@clusterpsp.wy5yj.mongodb.net/databaseTest1');

// Establecemos el esquema para realizar busquedas en la base de datos
let deportesSchema = new mongoose.Schema({
    deporte: String,
    nombre_equipo: String
});

// Definimos la variable para realizar busquedas
let Deporte = mongoose.model('collectionTest2', deportesSchema, 'collectionTest2');

// Esta busqueda devuelve TODOS los documentos que coinciden con la variable Deporte
Deporte.find({}).then(
    result => {
        console.log("Documentos encontrados:", result);
    }
).catch(
    error => {
        console.log("Error: ", error);
    }
);