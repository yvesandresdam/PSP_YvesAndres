// PARTE 5 - Practica 3
// CRUD DE DOCUMENTOS

// lineas de conexion con MongoDB
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://yveelilop:ClusterPSP@clusterpsp.wy5yj.mongodb.net/databaseTest1');
let deportesSchema = new mongoose.Schema({
    deporte: String,
    nombre_equipo: String
});

// creacion del esquema
let Deporte = mongoose.model('collectionTest1', deportesSchema, 'collectionTest1');

// Vamos a buscar un registro según su id
let id = '67c331f8b1e61630d8865c85'
Deporte.find({ _id: new mongoose.Types.ObjectId(id) })
    .then(result => console.log("Documentos encontrados:", result))
    .catch(error => console.log("Error: ", error));

// Podemos actualizar su valor de nombre_equipo
Deporte.findOneAndUpdate(
    { nombre_equipo: 'Lucentum HLA' },
    { nombre_equipo: 'HLA Alicante' },
    { new: true }
).then(doc => {
    if (doc) {
        console.log('Documento actualizado:', doc);
    } else {
        console.log('No se encontró el documento para actualizar.');
    }
}).catch(error => console.log('Error al actualizar:', error));

// Y por ultimo, tambien podemos borrar el registro
Deporte.findByIdAndDelete(id)
    .then(doc => {
        if (doc) {
            console.log('Documento eliminado:', doc);
        } else {
            console.log('No se encontró el documento con ese _id.');
        }
    })
    .catch(error => console.log('Error al eliminar:', error));