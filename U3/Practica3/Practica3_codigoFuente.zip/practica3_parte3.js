// PARTE 3 - Practica 3
// CREACION DE VARIOS DOCUMENTOS

const mongoose = require('mongoose');
// Añadimos todos los registros en una nueva coleccion

// Linea que conecta con el cluster y la base de datos
mongoose.connect('mongodb+srv://yveelilop:****@clusterpsp.wy5yj.mongodb.net/databaseTest1');

// Creamos el esquema para añadir una coleccion de documentos
let deportesSchema = new mongoose.Schema({
    deporte: String,
    nombre_equipo: String
});

// Creamos el documento
let Deporte = mongoose.model('collectionTest2', deportesSchema, 'collectionTest2');

// Creamos el dato que contiene el documento
let deporte1 = new Deporte({
    deporte: "Baloncesto",
    nombre_equipo: "Lucentum HLA"
});

// Guardamos el dato DENTRO de la coleccion
deporte1.save().then(
    result => {
        console.log("Asignatura añadida:", result);
    }
).catch(
    error => {
        console.log("Error añadiendo asignatura", error);
    }
);

// Creamos el dato que contiene el documento
let deporte2 = new Deporte({
    deporte: "Futbol",
    nombre_equipo: "Hercules CF"
});

// Guardamos el dato DENTRO de la coleccion
deporte2.save().then(
    result => {
        console.log("Asignatura añadida:", result);
    }
).catch(
    error => {
        console.log("Error añadiendo asignatura", error);
    }
);

// Creamos el dato que contiene el documento
let deporte3 = new Deporte({
    deporte: "Futbol",
    nombre_equipo: "CF Intercity Alicante"
});

// Guardamos el dato DENTRO de la coleccion
deporte3.save().then(
    result => {
        console.log("Asignatura añadida:", result);
    }
).catch(
    error => {
        console.log("Error añadiendo asignatura", error);
    }
);

// Creamos el dato que contiene el documento
let deporte4 = new Deporte({
    deporte: "Futbol Americano",
    nombre_equipo: "Alicante Sharks"
});

// Guardamos el dato DENTRO de la coleccion
deporte4.save().then(
    result => {
        console.log("Asignatura añadida:", result);
    }
).catch(
    error => {
        console.log("Error añadiendo asignatura", error);
    }
);